﻿$vCenters = @()
$vCenters += ,(New-Object -TypeName PSObject -Property @{
        'System Name' = 'SBM-PRD-VC-01';
        'IP Address'  = '10.149.98.50';
        'Common Name' = 'Siyanda Platinum - Production';
        'Platform'    = 'VMWARE'; # Valid Options are HyperVCluster, HyperVStandalone, VMWare, Dummy
        'Username'    = 'eohrt@vsphere.local';
        'Password'    = '30HP@ssw0rd';
    })
$vCenters += ,(New-Object -TypeName PSObject -Property @{
        'System Name' = 'SBM-DR-VC-01';
        'IP Address'  = '10.149.162.50';
        'Common Name' = 'Siyanda Platinum - DR';
        'Platform'    = 'VMWARE'; # Valid Options are HyperVCluster, HyperVStandalone, VMWare, Dummy
        'Username'    = 'eohrt@vsphere.local';
        'Password'    = '30HP@ssw0rd';
    })

For ($i = 0; $i -lt $vCenters.Count; $i ++) {
    Write-Host (($i + 1).ToString() + "/" + $vCenters.Count.ToString() + " Processing Report for " + $vCenters[$i].CommonName + " - ") -NoNewLine
    C:\EOH_RT\Scripts\RT-Full-Module_v3.ps1 -SystemName $vCenters[$i].'System Name' -IPAddress $vCenters[$i].'IP Address' -CommonName $vCenters[$i].'Common Name' -Platform $vCenters[$i].'Platform' -Username $vCenters[$i].'Username' -Password $vCenters[$i].'Password'
    Write-Host "Complete"
}