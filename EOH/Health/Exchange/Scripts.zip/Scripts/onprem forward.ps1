$result = @()
$mbx = Get-Mailbox -Filter {ForwardingAddress -ne $null} 
$mbx | foreach {
    $recipient = $_
    $forwardingsmtp = (Get-Recipient $_.ForwardingAddress).PrimarySmtpAddress
    $obj = New-Object PSObject
    $obj | Add-Member NoteProperty -Name "Name" -Value $recipient.Name
    $obj | Add-Member NoteProperty -Name "DN" -Value $recipient.DistinguishedName
    $obj | Add-Member NoteProperty -Name "Forwarding SMTP" -Value $forwardingsmtp
    $obj | Add-Member NoteProperty -Name "DeliverToMailboxAndForward" -Value $recipient.DeliverToMailboxAndForward
    $result = $result + $obj
}
$result | export-csv result.csv -NoTypeInformation