﻿Import-Module ActiveDirectory
Connect-MsolService
$Users = Import-CSV "C:\scripts\users.csv"
ForEach ($User in $Users){
#$UPN = $user.UPN
#$SMTP = $user.smtp
Set-ADUser -Identity $user.username -UserPrincipalName $User.SMTP
Set-MsolUserPrincipalName -UserPrincipalName $User.UPN -NewUserPrincipalName $User.SMTP
write-host "Changed UPN from ", $User.upn, " to ", $user.SMTP -foregroundcolor "Green"
}