$fwds = get-mailbox -ResultSize Unlimited | Where-Object { $_.ForwardingAddress -ne $null } | sort Name | select Name, PrimarySmtpAddress, ForwardingAddress

	foreach ($fwd in $fwds) {
$fwd | add-member -membertype noteproperty -name "ContactAddress" -value (get-Recipient $fwd.ForwardingAddress).PrimarySmtpAddress
}

$fwds | Export-Csv c:\forwardsoffice365.csv -NoTypeInformation