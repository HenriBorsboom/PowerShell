cd\
cd Scripts\
Connect-ExchangeServer -auto
.\South-Africa-ExchangeServerHealth.ps1 -ReportMode -SendEmail -MailFrom eohreport@eoh.com -MailTo drikus.visser@eoh.com -SMTPServer EOHBEDCAS02V.eohcorp.net