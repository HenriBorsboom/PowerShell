﻿param (
    [string] $path)
ls -Path $path
write-host $Out
