﻿#region Variables
    #region Usernames and Password
    $AdminUser = "bcxonline\hvi-admin"
    $AdminUserPassword = "Hv!Qdm1nP@ssw0rd"
    $CloudAdmin = "hvi-cloudadmin"
    $CloudAdminPassword = "Hv!Cl0ud@dm1nP@ssw0rd"
    $FileServerAdminServiceAccount = "bcxonline\HVI-WAPWEB-SVC"
    $FileServerAdminServiceAccountPassword = "Hv!W@pw3bP@ssw0rd"
    $FileShareOwnerServiceAccount = "bcxonline\HVI-WAPWEB-FSO-SVC"
    $FileShareOwnerServiceAccountPassword = "Hv!W@pw3bFS0P@ssw0rd"
    $FileShareUserServiceAccount = "bcxonline\HVI-WAPWEB-FSU-SVC"
    $FileShareUserServiceAccountPassword = "Hv!W@pw3bFSuP@ssw0rd"
    $CertificateShareUserServiceAccount = "bcxonline\HVI-WAPWEB-CSU-SVC"
    $CertificateShareUserServiceAccountPassword = "Hv!W@pw3bCs#P@ssw0rd"
    $ManagementServerAdminServiceAccount = "bcxonline\HVI-WAPWEB-MN-SVC"
    $ManagementServerAdminServiceAccountPassword = "Hv!W@pw3bMn@Password"
    $PublisherAdminServiceAccount = "bcxonline\HVI-WAPWEB-PB-SVC"
    $PublisherAdminServiceAccountPassword = "Hv!W@pw3bPbP@ssw0rd"
    $FrontEndAdminServiceAccount = "bcxonline\HVI-WAPWEB-FE-SVC"
    $FrontEndAdminServiceAccountPassword = "Hv!W@pw3bF3"
    $WorkerAdminServiceAccount = "bcxonline\HVI-WAPWEB-WW-SVC"
    $WorkerAdminServiceAccountPassword = "Hv!W@pw3bWw"
    #endregion

    #region Databse Settings
    $HostingDBString = 'Data Source=NRAZUREWEB108;Initial Catalog=Hosting;User ID=sa;Password=Hv!Sq7SerP@ssw0rd'
    $ResourceMeteringDBString = 'Data Source=NRAZUREWEB108;Initial Catalog=ResourceMetering;User ID=sa;Password=Hv!Sq7SerP@ssw0rd'
    #endregion
    
    #region Share Settings
    $contentShareUNCPath = "\\NRAZUREWEB107.bcxonline.com\WebSites"
    $contentShareLocalPath = "D:\Websites"
    $certificateShareUNCPath = "\\NRAZUREWEB107.bcxonline.com\Certificates"
    $certificateShareLocalPath = "D:\Websites"
    #endregion
    
    #region Other Settings
    $DNSSuffix = "websites.bcxonline.com"
    $FeedURL = "http://www.microsoft.com/web/wap/webapplicationlist.xml"
    #endregion

    #region Servers
    $ControllerServer = "NRAZUREWEB101.bcxonline.com"
    $ManagementServer = "NRAZUREWEB102.bcxonline.com"
    $FrontEndServer = "NRAZUREWEB103.bcxonline.com"
    $SharedWorkerServer = "NRAZUREWEB104.bcxonline.com"
    $ReservedMediumWorkerServer = "NRAZUREWEB105.bcxonline.com"
    $PublisherServer = "NRAZUREWEB106.bcxonline.com"
    $FileServer = "NRAZUREWEB107.bcxonline.com"
    $DatabaseServer = "NRAZUREWEB108.bcxonline.com"
    #endregion

#endregion

$Settings,@{}

$Settings.Add("hosting",$HostingDBString);
$Settings.Add("resourceMetering",$ResourceMeteringDBString);
$Settings.Add("managementServerAdminUserName",$ManagementServerAdminServiceAccount);
$Settings.Add("managementServerAdminPassword",$ManagementServerAdminServiceAccountPassword);
$Settings.Add("fileServerAdminUserName",$FileServerAdminServiceAccount);
$Settings.Add("fileServerAdminPassword",$FileServerAdminServiceAccountPassword);
$Settings.Add("frontEndAdminUserName",$FrontEndAdminServiceAccount);
$Settings.Add("frontEndAdminPassword",$FrontEndAdminServiceAccountPassword);
$Settings.Add("publisherAdminUserName",$PublisherAdminServiceAccount);
$Settings.Add("publisherAdminPassword",$PublisherAdminServiceAccountPassword);
$Settings.Add("workerAdminUserName",$WorkerAdminServiceAccount);
$Settings.Add("workerAdminPassword",$WorkerAdminServiceAccountPassword);
$Settings.Add("adminUserName",$AdminUser);
$Settings.Add("adminPassword",$AdminUserPassword);
$Settings.Add("dnsSuffix",$DNSSuffix);
$Settings.Add("managementServerName",$ManagementServer);
$Settings.Add("fileServerName",$FileServer);
$Settings.Add("fileServerType","WindowsSingle");
$Settings.Add("fileShareOwnerUserName",$FileShareOwnerServiceAccount);
$Settings.Add("fileShareOwnerPassword",$FileShareOwnerServiceAccountPassword);
$Settings.Add("fileShareUserUserName",$FileShareUserServiceAccount);
$Settings.Add("fileShareUserPassword",$FileShareUserServiceAccountPassword);
$Settings.Add("cloudAdminUserName",$CloudAdmin);
$Settings.Add("cloudAdminPassword",$CloudAdminPassword);
$Settings.Add("centralCertStoreUserName",$CertificateShareUserServiceAccount);
$Settings.Add("centralCertStorePassword",$CertificateShareUserServiceAccountPassword);
$Settings.Add("contentShareUNCPath",$contentShareUNCPath);
$Settings.Add("contentShareLocalPath",$contentShareLocalPath);
$Settings.Add("certificateShareUNCPath",$certificateShareUNCPath);
$Settings.Add("certificateShareLocalPath",$certificateShareLocalPath);
$Settings.Add("feedUrl",$FeedURL);
$Settings.Add("customFeeds",$FeedURL);
$Settings.Add("SQMEnabled","False");
$Settings.Add("MicrosoftUpdateEnabled","True");

Initialize-WebSitesExtension -Settings $controllerInitializationSettings -Verbose