﻿Import-Module FailoverClusters
Get-ClusterResource -c NRAZUREVMHC102 | where {$_.resourcetype.name -eq 'virtual machine configuration'} | Update-ClusterVirtualMachineConfiguration