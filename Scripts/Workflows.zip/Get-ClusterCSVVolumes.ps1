﻿Param (
    [Parameter(Mandatory=$false, Position = 1)]
    [String] $TargetCluster, `
    [Parameter(Mandatory=$false, Position = 2)]
    [Switch] $Domain, `
    [Parameter(Mandatory=$false, Position = 3)]
    [String] $DomainFQDN)
$ErrorActionPreference = "Stop"
Function GetCSVDetails {
    Param([Parameter(Mandatory=$true)] [String] $Cluster)

    $Objs = @()
    $CSVs = Get-ClusterSharedVolume -Cluster $Cluster
    ForEach ($CSV in $CSVs) {
       $CSVInfos = $CSV | Select -Property Name -ExpandProperty SharedVolumeInfo
       ForEach ($CSVInfo in $CSVInfos) {
          $Obj = New-Object PSObject -Property @{
             Name        = $CSV.Name
             Path        = $CSVInfo.FriendlyVolumeName
             Size        = $CSVInfo.Partition.Size
             FreeSpace   = $CSVInfo.Partition.FreeSpace
             UsedSpace   = $CSVInfo.Partition.UsedSpace
             PercentFree = $CSVInfo.Partition.PercentFree
          }
          $Objs += $Obj
       }
    }

    $ReturnOutput = ($Objs | ft -auto Name,Path,@{ Label = "Size(GB)" ; Expression = { "{0:N2}" -f ($_.Size/1024/1024/1024) } },@{ Label = "FreeSpace(GB)" ; Expression = { "{0:N2}" -f ($_.FreeSpace/1024/1024/1024) } },@{ Label = "UsedSpace(GB)" ; Expression = { "{0:N2}" -f ($_.UsedSpace/1024/1024/1024) } },@{ Label = "PercentFree" ; Expression = { "{0:N2}" -f ($_.PercentFree) } })
    Return $ReturnOutput
}
$ClusterResults = @()
Switch ($Domain) {
    $true {$Clusters = Get-Cluster -Domain $DomainFQDN; $Clusters = $Clusters.Name}
    $false {$Clusters = $TargetCluster}
}
If ($Clusters -eq $null -or $Clusters -eq "") {Throw}
ForEach ($Cluster in $Clusters) {
    Try {
        Write-Host "Getting " -NoNewline
        Write-Host $Cluster -NoNewline -ForegroundColor Cyan
        Write-Host " CSV Details - " -NoNewline
            $ClusterResults = $ClusterResults + ($Results = GetCSVDetails -Cluster $Cluster)
        Write-Host "Compete" -NoNewline -ForegroundColor Green
    
        $ExportFile = "C:\Temp\clusters\$Cluster.txt"
        If (!(Get-ChildItem $ExportFile)) {Remove-Item $ExportFile -Force}
        Write-Host " - Export to " -NoNewline
        Write-Host $ExportFile -NoNewline -ForegroundColor Cyan
        Write-Host " - " -NoNewline
            $Results | Out-File $ExportFile -Force -Encoding ascii
        Write-Host "Complete" -ForegroundColor Green
        $Results
    }
    Catch {
        Write-Host "Failed" -ForegroundColor Red
        Write-Output $_
    }
}
