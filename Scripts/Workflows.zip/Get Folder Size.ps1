﻿$ErrorActionPreference = "SilentlyContinue"
$startFolder = "\\NRAZUREVMH201\C$\ClusterStorage\Volume1"
$colItems = (Get-ChildItem $startFolder -recurse | Where-Object {$_.PSIsContainer -eq $True} | Sort-Object)
$EmptyFolders = @()
foreach ($i in $colItems)
    {
        $subFolderItems = (Get-ChildItem $i.FullName | Measure-Object -property length -sum)
        $Result = "{0:N2}" -f ($subFolderItems.sum / 1MB)
        #$Result.GetType()
        #Break
        
        If ($Result -eq "0,00") {
            $EmptyFolders = $EmptyFolders + $i.FullName
            }
        Else {}
    }
$EmptyFolders | Out-File C:\temp\EmptyFolders.TXT -Encoding ascii -Force
Notepad C:\temp\EmptyFolders.TXT