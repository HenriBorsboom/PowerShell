﻿$SCVMMSERVER = Get-SCVMMServer -ComputerName vmm01.bcxonline.com -ForOnBehalfOf 
get-vm -name StampVM |ft name, selfserviceuserrole, owner 
$vmnamesource = "StampVM"

$vmnametarget = "VIP-EFKON"

$vminfo = Get-SCVirtualMachine -name $vmnamesource

$vmowner = $vminfo.owner

$vmselfserviceuserrole = $vminfo.selfserviceuserrole

Set-SCVirtualMachine –VM $vmnametarget –UserRole $vmselfserviceuserrole –Owner $vmowner








