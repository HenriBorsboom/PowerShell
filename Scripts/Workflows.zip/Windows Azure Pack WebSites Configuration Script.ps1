﻿#region Variables
    #region Usernames and Password
    $AdminUser = "bcxonline\hvi-admin"
    $AdminUserPassword = "Hv!Qdm1nP@ssw0rd"
    $CloudAdmin = "hvi-cloudadmin"
    $CloudAdminPassword = "Hv!Cl0ud@dm1nP@ssw0rd"
    $FileServerAdminServiceAccount = "bcxonline\HVI-WAPWEB-SVC"
    $FileServerAdminServiceAccountPassword = "Hv!W@pw3bP@ssw0rd"
    $FileShareOwnerServiceAccount = "bcxonline\HVI-WAPWEB-FSO-SVC"
    $FileShareOwnerServiceAccountPassword = "Hv!W@pw3bFS0P@ssw0rd"
    $FileShareUserServiceAccount = "bcxonline\HVI-WAPWEB-FSU-SVC"
    $FileShareUserServiceAccountPassword = "Hv!W@pw3bFSuP@ssw0rd"
    $CertificateShareUserServiceAccount = "bcxonline\HVI-WAPWEB-CSU-SVC"
    $CertificateShareUserServiceAccountPassword = "Hv!W@pw3bCs#P@ssw0rd"
    $ManagementServerAdminServiceAccount = "bcxonline\HVI-WAPWEB-MN-SVC"
    $ManagementServerAdminServiceAccountPassword = "Hv!W@pw3bMn@Password"
    $PublisherAdminServiceAccount = "bcxonline\HVI-WAPWEB-PB-SVC"
    $PublisherAdminServiceAccountPassword = "Hv!W@pw3bPbP@ssw0rd"
    $FrontEndAdminServiceAccount = "bcxonline\HVI-WAPWEB-FE-SVC"
    $FrontEndAdminServiceAccountPassword = "Hv!W@pw3bF3"
    $WorkerAdminServiceAccount = "bcxonline\HVI-WAPWEB-WW-SVC"
    $WorkerAdminServiceAccountPassword = "Hv!W@pw3bWw"
    #endregion

    #region Databse Settings
    $HostingDBString = 'Data Source=NRAZUREWEB108;Initial Catalog=Hosting;User ID=sa;Password=Hv!Sq7SerP@ssw0rd'
    $ResourceMeteringDBString = 'Data Source=NRAZUREWEB108;Initial Catalog=ResourceMetering;User ID=sa;Password=Hv!Sq7SerP@ssw0rd'
    #endregion
    
    #region Share Settings
    $contentShareUNCPath = "\\NRAZUREWEB107.bcxonline.com\WebSites"
    $contentShareLocalPath = "D:\Websites"
    $certificateShareUNCPath = "\\NRAZUREWEB107.bcxonline.com\Certificates"
    $certificateShareLocalPath = "D:\Websites"
    #endregion
    
    #region Other Settings
    $DNSSuffix = "websites.bcxonline.com"
    $FeedURL = "http://www.microsoft.com/web/wap/webapplicationlist.xml"
    #endregion

    #region Servers
    $ControllerServer = "NRAZUREWEB101.bcxonline.com"
    $ManagementServer = "NRAZUREWEB102.bcxonline.com"
    $FrontEndServer = "NRAZUREWEB103.bcxonline.com"
    $SharedWorkerServer = "NRAZUREWEB104.bcxonline.com"
    $ReservedMediumWorkerServer = "NRAZUREWEB105.bcxonline.com"
    $PublisherServer = "NRAZUREWEB106.bcxonline.com"
    $FileServer = "NRAZUREWEB107.bcxonline.com"
    $DatabaseServer = "NRAZUREWEB108.bcxonline.com"
    #endregion

#endregion

Function  WebSiteCloudInit{
    # PowerShell script to configure Web Site Clouds
    Import-Module -Name MgmtSvcConfig
    Import-Module -Name Websites

    $WebSiteSettings = @{}
    # Hosting and ResourceMetering database connection strings.
    $WebSiteSettings.Add('hosting',$HostingDBString);
    $WebSiteSettings.Add('resourceMetering',$ResourceMeteringDBString);

    $WebSiteSettings.Add('dnsSuffix',$DNSSuffix);

    # Optional WebPI feed
    $WebSiteSettings.Add('feedUrl',$FeedURL);

    # Admin credentials 
    $WebSiteSettings.Add('adminUserName',$AdminUser);
    $WebSiteSettings.Add('adminPassword',$AdminUserPassword);

    # ManagementServer role settings (REST API)
    $WebSiteSettings.Add('managementServerName',$ManagementServer);
    $WebSiteSettings.Add('cloudAdminUserName',$CloudAdmin);
    $WebSiteSettings.Add('cloudAdminPassword',$CloudAdminPassword);

    # Optional credentials; admin credentials used if any are not specified.
    $WebSiteSettings.Add('managementServerAdminUserName',$ManagementServerAdminServiceAccount);
    $WebSiteSettings.Add('managementServerAdminPassword',$ManagementServerAdminServiceAccountPassword);
    $WebSiteSettings.Add('fileServerAdminUserName',$FileServerAdminServiceAccount);
    $WebSiteSettings.Add('fileServerAdminPassword',$FileServerAdminServiceAccountPassword);
    $WebSiteSettings.Add('frontEndAdminUserName',$FrontEndAdminServiceAccount);
    $WebSiteSettings.Add('frontEndAdminPassword',$FrontEndAdminServiceAccountPassword);
    $WebSiteSettings.Add('publisherAdminUserName',$PublisherAdminServiceAccount);
    $WebSiteSettings.Add('publisherAdminPassword',$PublisherAdminServiceAccountPassword);
    $WebSiteSettings.Add('workerAdminUserName',$WorkerAdminServiceAccount);
    $WebSiteSettings.Add('workerAdminPassword',$WorkerAdminServiceAccountPassword);

    # FileServer role settings (WebSites and Certificates shares)
    $WebSiteSettings.Add('fileServerName','NRAZUREWEB107');
    $WebSiteSettings.Add('fileServerType','WindowsSingle');
    $WebSiteSettings.Add('fileShareOwnerUserName',$FileShareOwnerServiceAccount);
    $WebSiteSettings.Add('fileShareOwnerPassword',$FileShareOwnerServiceAccountPassword);
    $WebSiteSettings.Add('fileShareUserUserName',$FileShareUserServiceAccount);
    $WebSiteSettings.Add('fileShareUserPassword',$FileShareUserServiceAccountPassword);     

    $WebSiteSettings.Add('centralCertStoreUserName',$CertificateShareUserServiceAccount);
    $WebSiteSettings.Add('centralCertStorePassword',$CertificateShareUserServiceAccountPassword);
    $WebSiteSettings.Add('contentShareUNCPath',$contentShareUNCPath);
    $WebSiteSettings.Add('contentShareLocalPath',$contentShareLocalPath);
    $WebSiteSettings.Add('certificateShareUNCPath',$certificateShareUNCPath);
    $WebSiteSettings.Add('certificateShareLocalPath',$certificateShareLocalPath);
    #$WebSiteSettings.Add('skipManagementServerProvisioning', 'False');
    #$WebSiteSettings.Add('isVMMBased','False');

    $WebSiteSettings
    Write-Host ""
    $Return = Read-Host "Are these settings correct (Y/N)? "
    $Return = $Return.ToLower()
    If ($Return -eq "y" -or $Return -eq "yes")
    {
        Initialize-WebSitesInstance -Settings $WebSiteSettings -Verbose
    }
    Else
    {
        Write-Host "Exit"
        Return
    
    }
    #Initialize-MgmtSvcFeature -Name HostingController -Settings $WebSiteSettings -Verbose
}

Clear-Host
WebSiteCloudInit