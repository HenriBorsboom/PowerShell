﻿# 1 Hyper-V,Failover-Clustering,Multipath-IO,RSAT,RSAT-Feature-Tools,RSAT-Clustering,RSAT-Clustering-Mgmt,RSAT-Clustering-PowerShell,RSAT-Role-Tools,RSAT-Hyper-V-Tools,Hyper-V-Tools,Hyper-V-PowerShell
# 2 NET-Framework-Features, NET-Framework-Core

Install-WindowsFeature -Name Hyper-V,Failover-Clustering,Multipath-IO,RSAT-Clustering-Mgmt,RSAT-Clustering-PowerShell,Hyper-V-Tools,Hyper-V-PowerShell -Restart