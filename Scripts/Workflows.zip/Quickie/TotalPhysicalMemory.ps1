﻿$Servers = @(
"NRAZUREWEB101", `
"NRAZUREWEB102", `
"NRAZUREWEB103", `
"NRAZUREWEB104", `
"NRAZUREWEB105", `
"NRAZUREWEB106", `
"NRAZUREWEB107", `
"NRAZUREWEB108", `
"NRAZUREWEB108", `
"NRAZUREAPP105", `
"NRAZUREAPP106", `
"NRAZUREAPP107", `
"NRAZUREAPP108", `
"NRAZUREAPP109", `
"NRAZUREAPP110", `
"NRAZUREAPP111")

ForEach ($Server in $Servers) {
$WMIRAM = Get-WmiObject -Query "select * from win32_logicaldisk" -ComputerName $Server

#$Total = $WMIRAM.TotalPhysicalMemory
#$Total = $Total / 1024 /1024 /1024
#$TotalGB = [System.Math]::Round($Total,2)
    ForEach ($Drive in $WMIRAM) {
        Write-Host $Server ' - ' $Drive.DeviceID ' - ' $Drive.Size ' - ' $Drive.FreeSpace 
    }
}