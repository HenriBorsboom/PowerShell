﻿$Web = @(
    "NRAZUREWEB101", `
    "NRAZUREWEB102", `
    "NRAZUREWEB103", `
    "NRAZUREWEB104", `
    "NRAZUREWEB105", `
    "NRAZUREWEB106", `
    "NRAZUREWEB107", `
    "NRAZUREWEB108")

ForEach ($Server in $Web) {
    Try {
        ForEach ($Server2 in $Web) {

        $Result = Invoke-Command -ComputerName $Server -ArgumentList $Server2 -ScriptBlock {winrm id -r:$Server2} -ErrorAction Stop
        Write-Host $Server "-" $Server2 "-" $Result
        }
    }
    Catch {
        Write-Host $Server "-" $_
    }
}