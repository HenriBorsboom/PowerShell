﻿#region Variables                                                                                                                                                                                                        #region Variables
    #region Usernames and Password
    $AdminUser = "bcxonline\hvi-admin"
    $AdminUserPassword = "Hv!Qdm1nP@ssw0rd"
    $CloudAdmin = "hvi-cloudadmin"
    $CloudAdminPassword = "Hv!Cl0ud@dm1nP@ssw0rd"
    $FileServerAdminServiceAccount = "bcxonline\HVI-WAPWEB-SVC"
    $FileServerAdminServiceAccountPassword = "Hv!W@pw3bP@ssw0rd"
    $FileShareOwnerServiceAccount = "bcxonline\HVI-WAPWEB-FSO-SVC"
    $FileShareOwnerServiceAccountPassword = "Hv!W@pw3bFS0P@ssw0rd"
    $FileShareUserServiceAccount = "bcxonline\HVI-WAPWEB-FSU-SVC"
    $FileShareUserServiceAccountPassword = "Hv!W@pw3bFSuP@ssw0rd"
    $CertificateShareUserServiceAccount = "bcxonline\HVI-WAPWEB-CSU-SVC"
    $CertificateShareUserServiceAccountPassword = "Hv!W@pw3bCs#P@ssw0rd"
    $ManagementServerAdminServiceAccount = "bcxonline\HVI-WAPWEB-MN-SVC"
    $ManagementServerAdminServiceAccountPassword = "Hv!W@pw3bMn@Password"
    $PublisherAdminServiceAccount = "bcxonline\HVI-WAPWEB-PB-SVC"
    $PublisherAdminServiceAccountPassword = "Hv!W@pw3bPbP@ssw0rd"
    $FrontEndAdminServiceAccount = "bcxonline\HVI-WAPWEB-FE-SVC"
    $FrontEndAdminServiceAccountPassword = "Hv!W@pw3bF3"
    $WorkerAdminServiceAccount = "bcxonline\HVI-WAPWEB-WW-SVC"
    $WorkerAdminServiceAccountPassword = "Hv!W@pw3bWw"
    #endregion

    #region Databse Settings
    $HostingDBString = 'Data Source=NRAZUREWEB108;Initial Catalog=Hosting;User ID=sa;Password=Hv!Sq7SerP@ssw0rd'
    $ResourceMeteringDBString = 'Data Source=NRAZUREWEB108;Initial Catalog=ResourceMetering;User ID=sa;Password=Hv!Sq7SerP@ssw0rd'
    #endregion
    
    #region Share Settings
    $contentShareUNCPath = "\\NRAZUREWEB107.bcxonline.com\WebSites"
    $contentShareLocalPath = "D:\Websites"
    $certificateShareUNCPath = "\\NRAZUREWEB107.bcxonline.com\Certificates"
    $certificateShareLocalPath = "D:\Websites"
    #endregion
    
    #region Other Settings
    $DNSSuffix = "websites.bcxonline.com"
    $FeedURL = "http://www.microsoft.com/web/wap/webapplicationlist.xml"
    #endregion

    #region Servers
    $ControllerServer = "NRAZUREWEB101.bcxonline.com"
    $ManagementServer = "NRAZUREWEB102.bcxonline.com"
    $FrontEndServer = "NRAZUREWEB103.bcxonline.com"
    $SharedWorkerServer = "NRAZUREWEB104.bcxonline.com"
    $ReservedMediumWorkerServer = "NRAZUREWEB105.bcxonline.com"
    $PublisherServer = "NRAZUREWEB106.bcxonline.com"
    $FileServer = "NRAZUREWEB107.bcxonline.com"
    $DatabaseServer = "NRAZUREWEB108.bcxonline.com"
    #endregion

#endregion

Function ConfigureWebSitesExtension
{
    Import-Module -Name MgmtSvcConfig
    Import-Module -Name Websites
    $ExtensionSettings = @{}

    $ExtensionSettings.Add("hosting",$HostingDBString);
    $ExtensionSettings.Add("resourceMetering",$ResourceMeteringDBString);
    $ExtensionSettings.Add("managementServerAdminUserName",$ManagementServerAdminServiceAccount);
    $ExtensionSettings.Add("managementServerAdminPassword",$ManagementServerAdminServiceAccountPassword);
    $ExtensionSettings.Add("fileServerAdminUserName",$FileServerAdminServiceAccount);
    $ExtensionSettings.Add("fileServerAdminPassword",$FileServerAdminServiceAccountPassword);
    $ExtensionSettings.Add("frontEndAdminUserName",$FrontEndAdminServiceAccount);
    $ExtensionSettings.Add("frontEndAdminPassword",$FrontEndAdminServiceAccountPassword);
    $ExtensionSettings.Add("publisherAdminUserName",$PublisherAdminServiceAccount);
    $ExtensionSettings.Add("publisherAdminPassword",$PublisherAdminServiceAccountPassword);
    $ExtensionSettings.Add("workerAdminUserName",$WorkerAdminServiceAccount);
    $ExtensionSettings.Add("workerAdminPassword",$WorkerAdminServiceAccountPassword);
    $ExtensionSettings.Add("adminUserName",$AdminUser);
    $ExtensionSettings.Add("adminPassword",$AdminUserPassword);
    $ExtensionSettings.Add("dnsSuffix",$DNSSuffix);
    $ExtensionSettings.Add("managementServerName",$ManagementServer);
    $ExtensionSettings.Add("fileServerName",$FileServer);
    $ExtensionSettings.Add("fileServerType","WindowsSingle");
    $ExtensionSettings.Add("fileShareOwnerUserName",$FileShareOwnerServiceAccount);
    $ExtensionSettings.Add("fileShareOwnerPassword",$FileShareOwnerServiceAccountPassword);
    $ExtensionSettings.Add("fileShareUserUserName",$FileShareUserServiceAccount);
    $ExtensionSettings.Add("fileShareUserPassword",$FileShareUserServiceAccountPassword);
    $ExtensionSettings.Add("cloudAdminUserName",$CloudAdmin);
    $ExtensionSettings.Add("cloudAdminPassword",$CloudAdminPassword);
    $ExtensionSettings.Add("centralCertStoreUserName",$CertificateShareUserServiceAccount);
    $ExtensionSettings.Add("centralCertStorePassword",$CertificateShareUserServiceAccountPassword);
    $ExtensionSettings.Add("contentShareUNCPath",$contentShareUNCPath);
    $ExtensionSettings.Add("contentShareLocalPath",$contentShareLocalPath);
    $ExtensionSettings.Add("certificateShareUNCPath",$certificateShareUNCPath);
    $ExtensionSettings.Add("certificateShareLocalPath",$certificateShareLocalPath);
    $ExtensionSettings.Add("feedUrl",$FeedURL);
    $ExtensionSettings.Add("customFeeds",$FeedURL);
    $ExtensionSettings.Add("SQMEnabled","False");
    $ExtensionSettings.Add("MicrosoftUpdateEnabled","True");

    $settings
    Write-Host ""
    $Return = Read-Host "Are these settings correct (Y/N)? "
    $Return = $Return.ToLower()
    If ($Return -eq "y" -or $Return -eq "yes")
    {
        Initialize-WebSitesExtension -Settings $controllerInitializationSettings -Verbose
    }
    Else
    {
        Write-Host "Exit"
        Return
    
    }
}