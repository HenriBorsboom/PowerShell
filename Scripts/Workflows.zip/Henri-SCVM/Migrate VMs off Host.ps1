﻿$VMS = Get-SCVirtualMachine -VMHost "NRAZUREVMH205"
$VMHosts = @(
"NRAZUREVMH201", `
"NRAZUREVMH202", `
"NRAZUREVMH203", `
"NRAZUREVMH204", `
"NRAZUREVMH206", `
"NRAZUREVMH207", `
"NRAZUREVMH208")
$x = 0
ForEach ($VM in $VMS) {
    If ($x -eq ($VMHosts.Count - 1)) {$x = 0}
    Else {
    $vmHost = Get-SCVMHost -ComputerName $VMHosts[$x] # | where { $_.Name -like $VMHosts[$x] }
    Move-SCVirtualMachine -VM $vm -VMHost $vmHost -HighlyAvailable $true -RunAsynchronously -UseDiffDiskOptimization
    Sleep (30)
    $x ++
    }
}