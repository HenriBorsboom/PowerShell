﻿Function Refresh-SCVMCluster {
    Param (
        [Parameter(Mandatory=$True)]
        [String] $TargetCluster)

    $ManagementCluster = @(
        "NRAZUREVMH101", `
        "NRAZUREVMH102")
    $IBMTenantCluster = @(
        "NRAZUREVMH201", `
        "NRAZUREVMH202", `
        "NRAZUREVMH203", `
        "NRAZUREVMH204", `
        "NRAZUREVMH205", `
        "NRAZUREVMH206", `
        "NRAZUREVMH207", `
        "NRAZUREVMH208")
    $IBMTenantSQLCluster  = @(
        "NRAZUREVMH104", `
        "NRAZUREVMH105")
#region Not Yet Deployed
    #$CiscoTenantCluster = @()
        #"NRAZUREVMH201", `
        #"NRAZUREVMH202", `
        #"NRAZUREVMH203", `
        #"NRAZUREVMH204", `
        #"NRAZUREVMH205", `
        #"NRAZUREVMH206", `
        #"NRAZUREVMH207", `
        #"NRAZUREVMH208")
    #$CiscoManagementCluster = @()
        #"NRAZUREVMH201", `
        #"NRAZUREVMH202", `
        #"NRAZUREVMH203", `
        #"NRAZUREVMH204", `
        #"NRAZUREVMH205", `
        #"NRAZUREVMH206", `
        #"NRAZUREVMH207", `
        #"NRAZUREVMH208")
    #$CiscoTenantSQLCluster = @()
        #"NRAZUREVMH201", `
        #"NRAZUREVMH202", `
        #"NRAZUREVMH203", `
        #"NRAZUREVMH204", `
        #"NRAZUREVMH205", `
        #"NRAZUREVMH206", `
        #"NRAZUREVMH207", `
        #"NRAZUREVMH208")
#endregion
    If ($Cluster = "ManagementCluster") {$Servers = $ManagementCluster}
    If ($Cluster = "IBMTenantCluster") {$Servers = $IBMTenantCluster}
    If ($Cluster = "IBMTenantSQLCluster") {$Servers = $IBMTenantSQLCluster}
    If ($Cluster = "CiscoTenantCluster") {$Servers = $CiscoTenantCluster}
    If ($Cluster = "CiscoManagementCluster") {$Servers = $CiscoManagementCluster}
    If ($Cluster = "CiscoTenantSQLCluster") {$Servers = $CiscoTenantSQLCluster}
    #ForEach ($Server in $Servers) {
    #    Write-Host $server "- " -NoNewline
    #    $Results = Get-SCVMHost -ComputerName $Server | Read-SCVMHost
    #    Write-Host "Complete"
    #}
    #Write-Host "Reading Cluster - " -NoNewline
    #$empty = Get-SCVMHostCluster -Name NRAZUREVMHC102
    #Write-Host "Complete"

    ForEach ($Server in $Servers) {
        Write-Host "Getting VMHost $Server - " -NoNewline
        $VMHost = Get-SCVMHost -ComputerName $Server
        Write-Host "Complete"

        Write-Host "Getting VMs on $Server - " -nonewline
        $VMs = Get-SCVirtualMachine -VMHost $VMHost
        Write-Host "Complete"
        ForEach ($VM in $VMs.Name) {
         Write-Host "Refreshing $VM on $Server - " -NonewLine
         $Empty = Get-SCVirtualMachine -Name $VM | Read-SCVirtualMachine
         Write-Host "Complete"
        }
    }
}
Write-Host "Possible Options: "
Write-Host "1) ManagementCluster"
Write-Host "2) IBMTenantCluster"
Write-Host "3) IBMTenantSQLCluster"
Write-Host "4) CiscoTenantCluster"
Write-Host "5) CiscoManagementCluster"
Write-Host "6) CiscoTenantSQLCluster"
Write-Host
$Selection = Read-Host "Selection (1 - 6): "
If ($Selection -eq 1) {RefreshSCVMCluster -TargetCluster "ManagementCluster"}
ElseIf ($Selection -eq 2) {RefreshSCVMCluster -TargetCluster "IBMTenantCluster"}
ElseIf ($Selection -eq 3) {Refresh-SCVMCluster -TargetCluster "IBMTenantSQLCluster"}
ElseIf ($Selection -eq 4) {Refresh-SCVMCluster -TargetCluster "CiscoTenantCluster"}
ElseIf ($Selection -eq 5) {Refresh-SCVMCluster -TargetCluster "CiscoManagementCluster"}
ElseIf ($Selection -eq 6) {Refresh-SCVMCluster -TargetCluster "CiscoTenantSQLCluster"}
Else {Write-Host "Invalid Option"}