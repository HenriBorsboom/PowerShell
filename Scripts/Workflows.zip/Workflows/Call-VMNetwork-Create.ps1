﻿workflow Call-VMNetwork-Create
{
    param($resourceObject)
        
    $UserRole =  $resourceObject.AdminId  #"AdminId":"test4@test.com"
    
    Create-VMNetwork -VmmServerName $VMMServer -OwnerUserRoleName $UserRole -CloudName $CloudName -LogicalNetworkName $LogicalNetworkName
}