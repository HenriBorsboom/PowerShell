﻿workflow Create-VMNetwork
{
    param
    (
        [string]$OwnerUserRole,
        [string]$VmmServerName,
        [string]$CloudName,
        [string]$LogicalNetworkName
    )
 
    inlinescript
    {
        $subnetValue = "10.0.0/24"
        $subnetName = "Tenant-Subnet"
        $dnsIP = "8.8.8.8"
        $ipAdressPoolName = "Tenant-IP-Pool"
        $ipAddressRangeStart = "10.0.0.1"
        $ipAddressRangeEnd = "10.0.0.254"
        $UserRole = $Using:OwnerUserRole
        $User = $UserRole.Split("_")[0]
        $vmNetworkName = "Tenant Network ($User)"
        
        Get-SCVMMServer -ComputerName $Using:VmmServerName -ForOnBehalfOf | Out-Null
        $OwnerUserRoleObj = Get-SCUserRole | where {$_.Name -match $Using:OwnerUserRole}

        $VMNetwork = Get-SCVMNetwork -OnBehalfOfUser $User -OnBehalfOfUserRole $OwnerUserRoleObj
        if(!$VMNetwork) 
        {
            $CloudObj = Get-SCCloud -Name $Using:CloudName
            $logicalNetwork = Get-SCLogicalNetwork -Cloud $CloudObj -Name $Using:LogicalNetworkName
            $vmNetwork = New-SCVMNetwork -Name $vmNetworkName -LogicalNetwork $logicalNetwork `
                -OnBehalfOfUser $User -OnBehalfOfUserRole $OwnerUserRoleObj
        
            $subnet = New-SCSubnetVLan -Subnet $subnetValue 
            $vmSubnet = New-SCVMSubnet -Name $subnetName -VMNetwork $vmNetwork -SubnetVLan $subnet `
                -OnBehalfOfUser $User -OnBehalfOfUserRole $OwnerUserRoleObj

            $allDnsServer = @($dnsIP)

            $staticIPAddressPool = New-SCStaticIPAddressPool -Name $ipAdressPoolName `
                -VMSubnet $vmSubnet -Subnet $subnetValue -IPAddressRangeStart $ipAddressRangeStart `
                -IPAddressRangeEnd $ipAddressRangeEnd -DNSServer $allDnsServer `
                -RunAsynchronously -OnBehalfOfUser $User -OnBehalfOfUserRole $OwnerUserRoleObj
        }
    
        #NAT, Gateway and External IP Address Pool Variables
        $vmGWServiceName = "RRAS-1 Windows Gateway Server"                                           ### 1
        $vmNetworkGwName = "{0}_Gateway" -f $vmNetworkName
        $vmExtStaticIPAddyPoolName = "Management IP Pool"                                            ###   2
        $vmNetworkNATConnName = "{0}_NatConnection" -f $vmNetworkName

        #NAT, Gateway and External IP Address Pool Commands
        $gatewayDevice = Get-SCNetworkGateway -Name $vmGWServiceName                                 ### 1
        $VmNetworkGateway = Add-SCVMNetworkGateway -Name $vmNetworkGwName -EnableBGP $false `
            -NetworkGateway $gatewayDevice -VMNetwork $vmNetwork `
            -OnBehalfOfUser $User -OnBehalfOfUserRole $OwnerUserRoleObj
        $externalIpPoolVar = Get-SCStaticIPAddressPool -Name $vmExtStaticIPAddyPoolName              ###   2
        $natConnection = Add-SCNATConnection -Name $vmNetworkNATConnName `
            -VMNetworkGateway $VmNetworkGateway -ExternalIPPool $externalIpPoolVar `
            -OnBehalfOfUser $User -OnBehalfOfUserRole $OwnerUserRoleObj 
    }
} 

