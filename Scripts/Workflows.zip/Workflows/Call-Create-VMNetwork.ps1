﻿$VMMServer = "vmm01.bcxonline.com" 
$UserRole = "test3@test.com" 
$CloudName = "My Tenant Cloud" 
$LogicalNetworkName = "RRAS-1 Logical Network" 

Create-VMNetwork -VmmServerName $VMMServer -OwnerUserRoleName $UserRole.Name -CloudName $CloudName -LogicalNetworkName $LogicalNetworkName