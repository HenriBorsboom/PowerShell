﻿workflow VMNetwork-Tenant
{
    param
    (
        [object]$resourceObject,
        [object]$params
    )
 
    $WAPSubscriptionId=$resourceObject.SubscriptionId
    $WAPAdminId=$resourceObject.AdminId
 
    InlineScript
    {
        $SubscriptionID =  $USING:WAPSubscriptionId
        $UserRole = $USING:WAPAdminId
        $UserRoleCut = $UserRole.Substring(0,27)
        $Under = "_"
        $Dot = "."
        $NameForSearch = $UserRoleCut + $Under + $SubscriptionID
 
        $NetworkName = "VirtualNetwork"
        $NetworkNameSuffix = Get-Random -Maximum 9999999
        $NetworkNameTemplate = $NetworkName + $Under + $NetworkNameSuffix
 
     Get-SCVMMServer -ComputerName "VMM01.BCXONLINE.COM" -ForOnBehalfOf | Out-Null
 
     $z = Get-SCUserRole | where {$_.Name -match $NameForSearch}
     $a = $UserRoleCut
 
     $NewVMNetwork = New-SCVMNetwork -Name $NetworkNameTemplate -LogicalNetwork "Converged Hyper Switch” -OnBehalfOfUser $a -OnBehalfOfUserRole $z
 
     [string]$octet1 = 10
     [string]$octet2 = 0
     [string]$octet3 = 0
     [string]$octet4 = 0
     $subnetmask = "/24"
 
     $GenerateVMNetworkSubnetID = $octet1 + $Dot + $octet2 + $Dot + $octet3 + $Dot + $octet4 + $subnetmask
 
     $CreateVMNetworkSubnet = New-SCSubnetVLan -Subnet $GenerateVMNetworkSubnetID
 
     [string]$RSID = Get-Random -Maximum 254
     $NameVMSubnetUnderVMNetworkTemplate = $NetworkNameTemplate + "_Subnet" + "_" + $RSID
     $CreateVMSubnetUnderVMNetwork = New-SCVMSubnet -Name $NameVMSubnetUnderVMNetworkTemplate -VMNetwork $NewVMNetwork -SubnetVLan $CreateVMNetworkSubnet -OnBehalfOfUser $a -OnBehalfOfUserRole $z
 
     $RangeStart = $octet1 + $Dot + $octet2 + $Dot + $octet3 + $Dot + "50"
     $RangeEnd = $octet1 + $Dot + $octet2 + $Dot + $octet3 + $Dot + "254"
 
     $ipAdressPoolName = $NetworkNameTemplate+"_Pool"
     $dnsIP = "8.8.8.8"
 
     $staticIPAddressPool = New-SCStaticIPAddressPool -Name $ipAdressPoolName -VMSubnet $CreateVMSubnetUnderVMNetwork -Subnet $GenerateVMNetworkSubnetID -IPAddressRangeStart $RangeStart -IPAddressRangeEnd $RangeEnd -DNSServer $dnsIP -OnBehalfOfUser $a -OnBehalfOfUserRole $z
 
     $NVGREGWName = "RRAS-1 Windows Gateway Server"
     $NVGREGWNameTemplate = "{0}_Gateway" -f $NVGREGWName
     $NVGREGWStaticIPPoolForIntenet = "Management IP Pool"
     $VMNetworkNATConnName = "{0}_NatConnection" -f $NetworkNameTemplate
     $NVGREGWOwn = Get-SCNetworkGateway -Name $NVGREGWName
     $ActivateNVGREGWForVMNetwork = Add-SCVMNetworkGateway -Name $NVGREGWNameTemplate -EnableBGP $false -NetworkGateway $NVGREGWOwn -VMNetwork $NewVMNetwork
     $NVGREExternalIPPOOL = Get-SCStaticIPAddressPool -Name $NVGREGWStaticIPPoolForIntenet
     $ActivateNAT = Add-SCNATConnection -Name $VMNetworkNATConnName -VMNetworkGateway $ActivateNVGREGWForVMNetwork -ExternalIPPool $NVGREExternalIPPOOL
    }
}