﻿workflow Create-VMNetwork
{
    param([object] $resourceObject)

    $OwnerUserRole=$resourceObject.AdminId
 
    inlinescript
    {
        $UserRole = $Using:OwnerUserRole
        $vmNetworkName = "Tenant Network ($UserRole)"
        $subnetValue = "10.0.0/24"
        $subnetName = "Tenant-Subnet"
        $dnsIP = "8.8.8.8"
        $ipAdressPoolName = "Tenant-IP-Pool"
        $ipAddressRangeStart = "10.0.0.2"
        $ipAddressRangeEnd = "10.0.0.254"
                
        Get-SCVMMServer -ComputerName "vmm01.bcxonline.com" -ForOnBehalfOf | Out-Null
        $OwnerUserRoleObj = Get-SCUserRole | Where-Object {$_.Name -match $UserRole}
        $VMNetwork = Get-SCVMNetwork -OnBehalfOfUser $UserRole -OnBehalfOfUserRole $OwnerUserRoleObj
        if(!$VMNetwork)
        {
            $CloudObj = Get-SCCloud -Name "BCX Online"
            $logicalNetwork = Get-SCLogicalNetwork -Cloud $CloudObj -Name "Converged Hyper Switch"
            $vmNetwork = New-SCVMNetwork -Name $vmNetworkName -LogicalNetwork $logicalNetwork -OnBehalfOfUser $UserRole -OnBehalfOfUserRole $OwnerUserRoleObj
            $subnet = New-SCSubnetVLan -Subnet $subnetValue
            $vmSubnet = New-SCVMSubnet -Name $subnetName -VMNetwork $vmNetwork -SubnetVLan $subnet -OnBehalfOfUser $UserRole -OnBehalfOfUserRole $OwnerUserRoleObj
            $allDnsServer = @($dnsIP)
            $staticIPAddressPool = New-SCStaticIPAddressPool -Name $ipAdressPoolName -VMSubnet $vmSubnet -Subnet $subnetValue -IPAddressRangeStart $ipAddressRangeStart -IPAddressRangeEnd $ipAddressRangeEnd -DNSServer $allDnsServer -RunAsynchronously -OnBehalfOfUser $UserRole -OnBehalfOfUserRole $OwnerUserRoleObj
        }
        $vmGWServiceName = "RRAS-1 Windows Gateway Server"
        $vmNetworkGwName = "{0}_Gateway" -f $vmNetworkName
        $vmExtStaticIPAddyPoolName = "Management IP Pool"
        $vmNetworkNATConnName = "{0}_NatConnection" -f $vmNetworkName
        $gatewayDevice = Get-SCNetworkGateway -Name $vmGWServiceName
        $VmNetworkGateway = Add-SCVMNetworkGateway -Name $vmNetworkGwName -EnableBGP $false -NetworkGateway $gatewayDevice -VMNetwork $vmNetwork
        $externalIpPoolVar = Get-SCStaticIPAddressPool -Name $vmExtStaticIPAddyPoolName
        $natConnection = Add-SCNATConnection -Name $vmNetworkNATConnName -VMNetworkGateway $VmNetworkGateway -ExternalIPPool $externalIpPoolVar
    }
}