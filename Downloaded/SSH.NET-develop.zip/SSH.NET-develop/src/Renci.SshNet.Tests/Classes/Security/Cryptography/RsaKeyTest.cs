﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Renci.SshNet.Tests.Common;

namespace Renci.SshNet.Tests.Classes.Security
{
    /// <summary>
    /// Contains RSA private and public key
    /// </summary>
    [TestClass]
    public class RsaKeyTest : TestBase
    {
    }
}