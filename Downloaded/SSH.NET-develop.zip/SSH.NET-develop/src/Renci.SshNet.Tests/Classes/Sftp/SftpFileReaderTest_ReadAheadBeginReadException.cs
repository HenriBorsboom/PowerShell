﻿namespace Renci.SshNet.Tests.Classes.Sftp
{
    class SftpFileReaderTest_ReadAheadBeginReadException
    {
    }
}
