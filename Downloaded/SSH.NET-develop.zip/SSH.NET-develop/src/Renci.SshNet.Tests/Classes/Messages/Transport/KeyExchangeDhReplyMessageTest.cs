﻿using Renci.SshNet.Messages.Transport;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Renci.SshNet.Tests.Common;

namespace Renci.SshNet.Tests.Classes.Messages.Transport
{
    /// <summary>
    ///This is a test class for KeyExchangeDhReplyMessageTest and is intended
    ///to contain all KeyExchangeDhReplyMessageTest Unit Tests
    ///</summary>
    [TestClass]
    public class KeyExchangeDhReplyMessageTest : TestBase
    {
        /// <summary>
        ///A test for KeyExchangeDhReplyMessage Constructor
        ///</summary>
        [TestMethod]
        [Ignore] // placeholder
        public void KeyExchangeDhReplyMessageConstructorTest()
        {
            KeyExchangeDhReplyMessage target = new KeyExchangeDhReplyMessage();
            Assert.Inconclusive("TODO: Implement code to verify target");
        }
    }
}
