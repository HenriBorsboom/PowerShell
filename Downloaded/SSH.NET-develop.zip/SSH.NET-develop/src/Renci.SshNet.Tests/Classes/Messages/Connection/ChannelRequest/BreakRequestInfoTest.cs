﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Renci.SshNet.Tests.Common;

namespace Renci.SshNet.Tests.Classes.Messages.Connection
{
    /// <summary>
    /// Represents "break" type channel request information
    /// </summary>
    [TestClass]
    public class BreakRequestInfoTest : TestBase
    {
    }
}